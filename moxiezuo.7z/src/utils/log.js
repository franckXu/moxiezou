export default function log(){
    console.log.apply(console,arguments)
}
