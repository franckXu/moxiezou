import wepy from 'wepy'

import {SERVER_PATH,REQ_CONFIG} from 'config'

export default function serivce(param){
    return new Promise((res,rej)=>{
        const req = Object.assign({
            data : param,
            success(resp) {
                res(resp)
            },
            fail(resp) {
                rej(resp)
            }
        },REQ_CONFIG())
        wepy.request(req)
    })
}
