import wepy from 'wepy';
import log from 'log';

import Input from '@/components/input/index';


export default class Index extends wepy.page {
    config = {}
    components = {
        ipt : Input
    }

    data = {
    }

    computed = {
    }

    methods = {
    }

    events = {}
    onLoad() {}

    onReady() {
        console.log(this.$parent.globalData);
    }

    onShow(){
    }


}
