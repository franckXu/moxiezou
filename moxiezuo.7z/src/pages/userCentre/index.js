import wepy from 'wepy'

import log from 'log'

export default class Index extends wepy.page {
    config = {}
    components = {}

    data = {
        userInfo: null
    }

    computed = {}

    methods = {
        toPage(page) {
            if (/jf/.test(page)) {
                wepy.navigateTo({
                    url: '/pages/jf/index'
                })
            }else{
                wepy.navigateTo({
                    url:'/pages/building/index'
                })
            }
        }
    }

    events = {}
    onLoad() {}

    onReady() {}

    onShow() {
        const self = this;
        this.$parent.getUserInfo(function({
            userInfo
        }) {
            log(userInfo)
            self.userInfo = userInfo
            self.$apply()
                // console.log('--',userInfo.userInfo.avatarUrl);
        })
    }


}
