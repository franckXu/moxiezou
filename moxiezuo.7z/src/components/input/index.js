  import wepy from 'wepy'
  export default class Component extends wepy.component {

  }
