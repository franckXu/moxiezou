{
  "originalData": {
    "status": 0,
    "result": {
      "location": {
        "lng": 113.26443483100965,
        "lat": 23.129163884083894
      },
      "formatted_address": "广东省广州市越秀区府前路",
      "business": "东风,大新,广卫",
      "addressComponent": {
        "country": "中国",
        "country_code": 0,
        "country_code_iso": "CHN",
        "province": "广东省",
        "city": "广州市",
        "city_level": 2,
        "district": "越秀区",
        "town": "",
        "adcode": "440104",
        "street": "府前路",
        "street_number": "",
        "direction": "",
        "distance": ""
      },
      "pois": [],
      "roads": [],
      "poiRegions": [
        {
          "direction_desc": "内",
          "name": "广州市人民政府办公厅",
          "tag": "政府机构"
        }
      ],
      "sematic_description": "广州市人民政府办公厅内,广州市交通委员会(府前路)附近0米",
      "cityCode": 257
    }
  },
  "wxMarkerData": [
    {
      "id": 0,
      "latitude": 23.129163,
      "longitude": 113.264435,
      "address": "广东省广州市越秀区府前路",
      "iconPath": "../../images/marker_red.png",
      "iconTapPath": "../../images/marker_red.png",
      "desc": "广州市人民政府办公厅内,广州市交通委员会(府前路)附近0米",
      "business": "东风,大新,广卫",
      "alpha": 1
    }
  ]
}
