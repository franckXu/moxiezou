export const REQUEST_FAIL = "请求失败";

// export const SERVER_PATH = 'http://127.0.0.1:7001/mxz';
export const SERVER_PATH = 'http://39.108.103.238:8088/mmd/itf';

export const headers = {
    method: 'POST',
    url: SERVER_PATH,
    dataType: 'json'
}
