import wepy from 'wepy';

import log from 'log';
import {
    toast
} from '@/utils/index';
import {
    REQUEST_FAIL
} from 'config';

import consumeListService from "./consumeList.service"
import productInfoService from "./productInfo.service.js"

export default class Index extends wepy.page {
    config = {}
    components = {}

    data = {
        productInfo: {},
        consumeList: [],
    }

    computed = {}

    methods = {
        handlerConsumeItem(productId) {
            wepy.requestPayment({
                "timeStamp": ""+Date.now(), // String	是	时间戳从1970年1月1日00:00:00至今的秒数,即当前的时间
                "nonceStr": Math.random().toString(36).substr(2), // String	是	随机字符串，长度为32个字符以下。
                "package": "", // String	是	统一下单接口返回的 prepay_id 参数值，提交格式如：prepay_id=*
                "signType": "MD5", // String	是	签名算法，暂支持 MD5
                "paySign": "", // String	是	签名,具体签名方案参见小程序支付接口文档;
                "success": function(res) {
                    log(res)
                },
                "fail": function({errMsg}) {
                    toast({title : errMsg})
                    log(errMsg)
                },
                "complete": function() {
                    log('complete')
                    // 6.5.2 及之前版本中，用户取消支付不会触发 fail 回调，只会触发 complete 回调，回调 errMsg 为 'requestPayment:cancel'
                } // Function	否	接口调用结束的回调函数（调用成功、失败都会执行）
            })
        }
    }

    events = {}

    onLoad() {

    }

    onReady() {
        this.reqConsumeList()
        this.reqProductInfo()
    }

    reqConsumeList() {
        consumeListService({
            funcId: 'TODO',
            idx: '123'
        }).then(({ data: { resultCode, resultMsg, data } }) => {
            if (resultCode === "0000") {
                this.consumeList = data
            } else {
                this.consumeList = [{
                    idx: 1,
                    price: 50,
                    text: '身体放松坐',
                    time: '5.00元6分钟'
                }, {
                    idx: 2,
                    price: 150,
                    text: '身体放松坐',
                    time: '150.00元66分钟'
                }, {
                    idx: 3,
                    price: 100,
                    text: '身体放松坐,身体放松坐',
                    time: '100.00元16分钟'
                }];
                this.$apply()
                log(resultMsg)
                toast({
                    title: '查询失败'
                })
            }

        }, err => {
            toast({
                title: REQUEST_FAIL
            })
        })
    }

    reqProductInfo() {
        productInfoService({
            funId: 'TODO',
            idx: 'TODO'
        }).then(({data:{ data, resultMsg, resultCode }}) => {
            if (resultCode === "0000") {
                this.productInfo = data
            } else {
                toast({
                    titile: resultMsg
                })
            }
        }, err => {
            log(err)
            toast({
                title: REQUEST_FAIL
            })
        })
    }

}
