import wepy from 'wepy'

import log from 'log'

export default class Index extends wepy.page {
    config = {}
    components = {}

    data = {
    }

    computed = {
    }

    methods = {
    }

    events = {}
    onLoad() {}

    onReady() {
    }

    onShow(){
    }


}
